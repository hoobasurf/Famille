# 📱 Icônes Famille – Tous formats

## Structure des fichiers à placer dans ton repo

```
/
├── index.html          ← Contient toutes les balises <link> / <meta> pour chaque plateforme
├── manifest.json       ← PWA manifest pour Android / Chrome
└── icons/
    ├── web/
    │   ├── favicon.ico         ← Navigateurs bureau
    │   ├── favicon-16x16.png
    │   ├── favicon-32x32.png
    │   ├── icon-48x48.png
    │   ├── icon-72x72.png
    │   ├── icon-96x96.png
    │   ├── icon-128x128.png
    │   ├── icon-144x144.png    ← Windows Tile
    │   ├── icon-152x152.png
    │   ├── icon-167x167.png
    │   ├── icon-180x180.png
    │   ├── icon-192x192.png    ← Android / PWA
    │   ├── icon-256x256.png
    │   ├── icon-384x384.png
    │   └── icon-512x512.png    ← PWA maskable
    ├── ios/
    │   ├── AppIcon-20@1x.png    (20×20)
    │   ├── AppIcon-20@2x.png    (40×40)
    │   ├── AppIcon-20@3x.png    (60×60)
    │   ├── AppIcon-29@1x.png    (29×29)
    │   ├── AppIcon-29@2x.png    (58×58)
    │   ├── AppIcon-29@3x.png    (87×87)
    │   ├── AppIcon-40@1x.png    (40×40)
    │   ├── AppIcon-40@2x.png    (80×80)
    │   ├── AppIcon-40@3x.png    (120×120)
    │   ├── AppIcon-60@2x.png    (120×120)
    │   ├── AppIcon-60@3x.png    (180×180)  ← iPhone écran d'accueil
    │   ├── AppIcon-76@1x.png    (76×76)
    │   ├── AppIcon-76@2x.png    (152×152)  ← iPad
    │   ├── AppIcon-83.5@2x.png  (167×167)  ← iPad Pro
    │   └── AppIcon-1024.png     (1024×1024) ← App Store
    └── android/
        ├── mipmap-mdpi/ic_launcher.png     (48×48)
        ├── mipmap-hdpi/ic_launcher.png     (72×72)
        ├── mipmap-xhdpi/ic_launcher.png    (96×96)
        ├── mipmap-xxhdpi/ic_launcher.png   (144×144)
        └── mipmap-xxxhdpi/ic_launcher.png  (192×192)
```

## Déploiement sur Netlify

1. Copie tous ces fichiers dans ton repo GitHub en **respectant exactement la structure** ci-dessus
2. Push sur `main`
3. Netlify détecte le `index.html` et déploie automatiquement
4. L'icône apparaîtra sur l'écran d'accueil iOS, Android, tablette et PC

## Résultat

- ✅ **iPhone / iPad** → Ajout à l'écran d'accueil → icône correcte
- ✅ **Android** → "Ajouter à l'écran d'accueil" / PWA installable
- ✅ **PC / Mac** → Favicon dans le navigateur + site épinglé Windows
- ✅ **Tablettes** → iOS et Android couverts
